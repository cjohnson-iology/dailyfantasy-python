#!/usr/env python

'''
dk-salaries.py

used to download 2014-15 nba daily fantasy salary data from RotoGuru
season starts 10-28-2014, season ends on 4-15-2015

this was a first hack; found alternate method using RotoGuruParser and RotoGuruScraper classes

this HTML is more structured but not that easy to scrape due to lack of ids, nested tables,
td elements which include multiple values, etc.

this script and the associated files should be mothballed in case other script doesn't work
i have the files and can always go back and figure out a way to process this if there is no better way
'''

import httplib2
from urllib import urlencode
import time

def get_from_web(url, fn=None):
  # content is none if file can't be downloaded
  content = None

  # try to download, if successful, then save file
  (resp, body) = handler.request(url, "GET")

  # want to make sure that get the correct content, so check request status before returning content
  if resp.status == 200:
    content = body

  # save content to a file if fn passed as parameter
  if fn:
    with open(fn, 'w') as outfile:
      outfile.write(content)

  return content

if __name__ == "__main__":
  handler = httplib2.Http(".cache")
  base_url = 'http://rotoguru1.com/cgi-bin/hyday.pl?'

  months = ['10', '11', '12', '1', '2', '3', '4']
  month_days = {'10': range(28, 31), '11': range(1,30), '12': range(1,31), '1': range(1,31), '2': range(1,28), '3': range(1,31), '4': range(1,11)} 

  for month in months:
    for day in month_days[month]:
      params = {'mon': month, 'day': day, 'game': 'dk'}
      fn = 'dk_' + str(month) + '-' + str(day) + '-2015.html'
      url = base_url + urlencode(params)
      content = get_from_web(url, fn)
      time.sleep(3)

